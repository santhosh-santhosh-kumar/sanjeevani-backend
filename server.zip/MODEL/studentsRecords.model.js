const express = require("express");
const { Schema, model } = require("mongoose");

const schema = new Schema({
  fullName: { type: String, require: true },
  status: { type: String, require: true },
  dob: { type: Date, require: true },
  age: { type: Number, require: true },
  gender: { type: String, require: true },
  email: { type: String, require: true },
  currentStandard: { type: String, require: true },
  fatherName: { type: String, require: true },
  motherName: { type: String, require: true },
  fatherPhone: { type: Number, require: true },
  personal_conductMOB: { type: String, require: true },
  residentialAddress: { type: String, require: true },
  join_date: { type: Date },
  batchID: { type: String, require: true },
  student_info: { type: String, require: true },
  attentance:[{
    attentanceStatus:{type: Boolean,require: true },
    attentanceDate:{type: Date},
  }],
  imageUrls: { type: String },
  filename: { type: String },
  paymentRecords:[
    {
    month:[
      {
        monthName:String,
        paymentOderID:String,
        paymentID:String,
        payment_status: { type: Boolean,require: true},
        paid_date: { type: Date,default:Date.now() },
        received_payment: { type: Number },
        paymentPerMonthTotal:{type: Number,require: true },      
      }
    ]
  }
],
  paymentTotal:{type: Number,require: true },
  paymentDue:{type: Number,require: true },
  dueMonthCount:{type: Number,require: true },
  userName:{
    type:String,
    require:true,
},
password:{
    type:String,
    require:true,            
},
confirm_password:{
  type:String,
  require:true,            
},
});

const studentsRecords = model("studentsRecords", schema);

module.exports = studentsRecords;
