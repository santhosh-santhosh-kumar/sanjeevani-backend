const api = [
  {
    userName: "student name",
    dob: "xxxxx",
    age: "22",
    gender: "xxxxx",
    email: "xxxxxx",
    current_work: "xxxxx",
    fatherName: "xxxxx",
    motherName: "xxxxx",
    parents_conduct_mob: "xxxxxxxx",
    personal_conduct_mob: "xxxxxxx",
    address: "xxxxxxxxxxxx",
    payment_status: "unpaid",
    join_date: "xxxxxxx",
    batchID: "SKBM001",
    status: false,
    received_payment: 2000,
    student_info: "new",
    image: "url",
  }
]

//user name and password setup

const user = [
  {
    userName: "student name",
    email: "xxxxxx",
    password: "xxxxxx",
    conform_password: "xxxxxx",
  }
]


//payment for new students

//payment for existing students



